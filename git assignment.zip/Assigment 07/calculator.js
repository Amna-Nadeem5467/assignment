const display = document.getElementById('display');

function appendToDisplay(value) {
    if (display.value === '0' && value !== '.') {
        display.value = value;
    } else {
        display.value += value;
    }
}

function clearDisplay() {
    display.value = '0';
}

function calculateResult() {
    try {
        display.value = eval(display.value);
    } catch (e) {
        display.value = 'Error';
    }
}

function startPromptCalculation() {
    const num1_input = prompt("Enter the first number:");
    const num1 = parseFloat(num1_input);

    if (isNaN(num1)) {
        alert("Invalid first number.");
        document.getElementById('prompt-result-display').textContent = "Calculation failed: Invalid first number.";
        return;
    }

    const operation = prompt("Enter the operation (+, -, *, /):");

    if (!['+', '-', '*', '/'].includes(operation)) {
        alert("Invalid operation.");
        document.getElementById('prompt-result-display').textContent = "Calculation failed: Invalid operation.";
        return;
    }

    const num2_input = prompt("Enter the second number:");
    const num2 = parseFloat(num2_input);

    if (isNaN(num2)) {
        alert("Invalid second number.");
        document.getElementById('prompt-result-display').textContent = "Calculation failed: Invalid second number.";
        return;
    }

    let result;

    switch (operation) {
        case '+':
            result = num1 + num2;
            break;
        case '-':
            result = num1 - num2;
            break;
        case '*':
            result = num1 * num2;
            break;
        case '/':

            if (num2 === 0) {
                alert("Cannot divide by zero!");
                document.getElementById('prompt-result-display').textContent = "Calculation failed: Division by zero.";
                return;
            }
            result = num1 / num2;
            break;
        default:

            alert("An unexpected error occurred.");
            document.getElementById('prompt-result-display').textContent = "Calculation failed: Unexpected error.";
            return;
    }

    const resultText = `Result: ${num1} ${operation} ${num2} = ${result}`;

    document.getElementById('prompt-result-display').textContent = resultText;
    
    alert(resultText);
}